def two_argument_list(b, a):
    lst1 = []
    lst2 = []
    if type(b) == int or type(b) == float:
        print(list(str(b)))
    if type(a) == int or type(a) == float:
        print(list(str(a)))
    if type(b) == str or type(b) == set or type(b) == tuple:
        print(list(b))
    if type(a) == str or  type(a) == set or type(a) == tuple:
         print(list(a))
    if type(b) == dict:
        for i, v in b.items():
            lst1.append(i)
            lst1.append(v)
        print(lst1)
    if type(a) == dict:
        for k, x in a.items():
            lst2.append(k)
            lst2.append(x)
        print(lst2)

two_argument_list('a', {1:'y', 2:'z'})