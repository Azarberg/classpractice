import random

def N_list():
    lst = []
    n = int(input('Введите число больше нуля:'))
    while len(lst) != n:
        t = random.randrange(0,n)
        lst.append(t)
    print(lst)
N_list()
