#Создайте 4 функции: add(), substract(), multiply(), divide() 
#которые будут принимать по 2 аргумента и возвращать результат: сложения, вычитания, умножения и деления
def add(a,b):
	print(a+b)
add(5,4)
def substract(a,b):
	print(a-b)
substract(8,1)
def multiply(a,b):
	print(a*b)
multiply(4,6)
def divide(a,b):
	if b == 0:
		print('Нельзя делить на 0')
	else:
		print(a/b)
divide(1,0)
