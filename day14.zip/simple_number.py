i = 0
n = int(input('Введите  число:'))
for i in range(2,100):
    if n%i == 0  and i != n:
        print('Число   не является простым')
        break
    else:
        print('Число является простым')
        break
