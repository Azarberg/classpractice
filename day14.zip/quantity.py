def quantity_symbol(text):
    total = 0
    for _ in text.strip():
        total += 1

    return total


result = quantity_symbol('1233   ')
print(result)
