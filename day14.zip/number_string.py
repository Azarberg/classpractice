n = int(input('Введите число:'))
text = ' '
text = n*n*(str(n))
t = ' '.join([text[i:i+n] for i in range(0, len(text), n)])
print(t)

