def dict_to_tuples(dict):
    dict = {'1': 'a', '2': 'b', '3': 'c'}
    lst1 = []
    lst2 = []
    for k in dict.keys():
        lst1.append(k)
    print(tuple(lst1))
    for v in dict.values():
        lst2.append(v)
    print(tuple(lst2))

dict_to_tuples(dict)



