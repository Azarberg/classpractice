#Напишите функцию которая принимает 2 Dictionary и добавляет втрорую Dictionary к первой.
def twodictionary(d1,d2):
     d1.update(d2)
     return d1

d3 = twodictionary({'1': 1}, {"a": 1})
print(d3)