def name_salary():
    name = input('Введите имя')
    salary = int(input('Введите зарплату'))
    print(f" {name} - {salary}")

name_salary()