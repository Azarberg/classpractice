def func1():
    def func2():
        print('Я вложенная функция.')
    return func2()
print('Я главная функция')

func1()

