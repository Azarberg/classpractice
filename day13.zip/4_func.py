def  fff():
	name_file = input('Введите название файла:')
	with open(f'{name_file}.txt', 'w') as f:
		r = f.write("a")

a = fff
a()
