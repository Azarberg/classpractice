#Создайте функцию сложения, затем функцию вычитания двух чисел...
#Создайте 3-ю функцию которая вызывает первые 2 внутр

def  summa(a,b):
	s = a+b
	print(s)
summa(20,6)

def minus(a,b):
	s = a-b
	print(s)
minus(15,20)

def  sum_minus(a,b):
	s1 = a+b
	s2 = a-b
	print(s1,s2)
sum_minus(24,8)
