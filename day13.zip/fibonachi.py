lst = []

def fib():
	a,b = 1,1
	for _ in range(1,11):
		lst.append(a)
		a,b = b,a + b	
fib()
print(lst)
