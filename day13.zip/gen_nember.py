import random

def gen_number():
	lst1 = ['0', '4', '4', '4']
	lst = ['1', '4', '5', '7', '9', '0']
	for i in range(6):
		i = random.choice(lst)
		lst1.append(i)
	print("".join(lst1))
gen_number()
