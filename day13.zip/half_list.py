
lst = [1, 2, 3, 4]

def list_half_reverse(lst):
	mid = len(lst)//2
	lst = lst[::-1]
	left = lst[:mid]
	right = lst[mid:]
	print(left, right)

list_half_reverse([1, 2, 3, 4, 5, 6])
