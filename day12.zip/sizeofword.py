import sys
a = input('Введите слово:')
b = input('Введите слово:')
print(sys.getsizeof(a),sys.getsizeof(b))

