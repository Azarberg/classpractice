# определим имя директории, которую создаём

import os
import random

path = "/home/azamat/Desktop/papka"
words = ["asd", "dsa", "asdw", "asddd", "asdasd"]

os.mkdir(path)
for i in range(5):
	file = open(path+f"/{random.choice(words)}.py", "w")
	word = random.choice(words)
	file.write(word)
	file.close()
