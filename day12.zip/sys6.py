import sys 

print(sys.argv[0],sys.argv[1],sys.argv[2],sys.argv[3])
