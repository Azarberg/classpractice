import random
names = ["Aibek", "Joomart", "Adinai", "Ermek", "Atai", "Aslan", "Lyazat", "Salavat", "Daniyar", "Bolotbek", "Alymbek", "Dastan", "Maksat"]
lst = []
while len(lst) != 4:
	n = random.choice(names)
	if n not in lst:
		lst.append(n)
print(lst)
