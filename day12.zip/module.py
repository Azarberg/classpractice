#Внутри my_module.py создайте вызваннную print которая выводит текст "Я функция из my_module.py".
# А затем импортируйте my_module.py в другой файл.
t = 'Я функция из my_module.py'
print(t)

