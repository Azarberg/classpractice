import random
print(random.randrange(6,13))
n = random.randrange(0,101,5)
print(n)

	

