import random
l = input('Введите камень/ножница/бумага:')
lst = ['stone', ' scissors', 'paper']
n = random.choice(lst)
if l == 'stone' and n == 'scissors' or l == 'scissors' and n == 'paper' or l == 'paper' and n == 'stone':
	print(n,'\n You win')
elif n == 'stone' and l == 'scissors' or n == 'scissors' and l == 'paper' or n == 'paper' and l == 'stone':
	print(n,'\n You loose')
else:
	print(n,'\n Draw')
